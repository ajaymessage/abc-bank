package com.abc;


import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Transaction {
    public final double amount;

    private Date transactionDate;

    public Transaction(double amount) {
        this.amount = amount;
        this.transactionDate = DateProvider.getInstance().now();
    }
    
// Ajay Added    
    public boolean isOlder(int noDays) {
    	long diff = DateProvider.getInstance().now().getTime() - transactionDate.getTime();
    	if(TimeUnit.MILLISECONDS.toDays(diff) > noDays)
    		return true;
    	return false;
    }

}
