package com.abc;


import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class CustomerTest {
	private static final double DOUBLE_DELTA = 1e-15;
	
    @Test //Test customer statement generation
    public void testApp(){

    	
        Account checkingAccount = new Account(Account.CHECKING);
        Account savingsAccount = new Account(Account.SAVINGS);

        Customer henry = new Customer("Henry").openAccount(checkingAccount).openAccount(savingsAccount);

        checkingAccount.deposit(100.0);
        savingsAccount.deposit(4000.0);
        savingsAccount.withdraw(200.0);

        assertEquals("Statement for Henry\n" +
                "\n" +
                "Checking Account\n" +
                "  deposit $100.00\n" +
                "Total $100.00\n" +
                "\n" +
                "Savings Account\n" +
                "  deposit $4,000.00\n" +
                "  withdrawal $200.00\n" +
                "Total $3,800.00\n" +
                "\n" +
                "Total In All Accounts $3,900.00", henry.getStatement());
    }

    
    @Test
    public void testOneAccount(){
        Customer oscar = new Customer("Oscar").openAccount(new Account(Account.SAVINGS));
        assertEquals(1, oscar.getNumberOfAccounts());
    }

    @Test
    public void testTwoAccount(){
        Customer oscar = new Customer("Oscar")
                .openAccount(new Account(Account.SAVINGS));
        oscar.openAccount(new Account(Account.CHECKING));
        assertEquals(2, oscar.getNumberOfAccounts());
    }

    @Ignore
    public void testThreeAcounts() {
        Customer oscar = new Customer("Oscar")
                .openAccount(new Account(Account.SAVINGS));
        oscar.openAccount(new Account(Account.CHECKING));
        assertEquals(3, oscar.getNumberOfAccounts());
    }
    
    
    // Ajay Added
    @Test
    public void testOverDraft() {
        Account checkingAccount = new Account(Account.CHECKING);

        checkingAccount.deposit(500.0);
        checkingAccount.withdraw(200.0);
        try {
        	checkingAccount.withdraw(800.0);
        fail("Exception not thrown for overDraft");
        }catch(Exception exc) {
        	System.out.println("failed as expected");
        }    	
    }

        
    @Test
    public void testMaxiSavingInterest() {
        Account account = new Account(Account.MAXI_SAVINGS);

        account.deposit(1000.0);
        assertEquals(50.0, account.interestEarned(), DOUBLE_DELTA);
        account.withdraw(100);
        account.deposit(100);
        assertEquals(1.0, account.interestEarned(), DOUBLE_DELTA);   	
    }
    
    @Test 
    public void testTransfer(){    	
        Account checkingAccount = new Account(Account.CHECKING);
        Account savingsAccount = new Account(Account.SAVINGS);

        Customer henry = new Customer("Henry").openAccount(checkingAccount).openAccount(savingsAccount);

        checkingAccount.deposit(150.0);
        savingsAccount.deposit(250.0);
        henry.transfer(Account.CHECKING, Account.SAVINGS, 50);
        assertEquals(100.0, checkingAccount.sumTransactions(), DOUBLE_DELTA);
        assertEquals(300.0, savingsAccount.sumTransactions(), DOUBLE_DELTA);
        
        Customer oscar = new Customer("Oscar")
        .openAccount(new Account(Account.SAVINGS));
        assertEquals(false, oscar.transfer(Account.CHECKING, Account.SAVINGS, 50));
    }    
}
